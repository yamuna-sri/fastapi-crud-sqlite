# 🚀 FastAPI CRUD with SQLite (Error‑free, production‑ready starter)

This project implements **CRUD (Create, Read, Update, Delete)** for a `User` resource using **FastAPI**, **SQLAlchemy 2.x**, **Pydantic v2**, and **SQLite**.

## 📖 What is CRUD?
- **Create** (`POST`) — Add a new record
- **Read** (`GET`) — Retrieve one or more records
- **Update** (`PATCH/PUT`) — Modify existing record(s)
- **Delete** (`DELETE`) — Remove a record

---

## 📂 Project Structure
```
fastapi-crud-sqlite/
├─ app/
│  ├─ __init__.py
│  ├─ main.py               # FastAPI app, startup (creates tables)
│  ├─ database.py           # Engine, SessionLocal, Base, get_db()
│  ├─ models.py             # SQLAlchemy ORM models
│  ├─ schemas.py            # Pydantic v2 schemas
│  ├─ crud.py               # CRUD functions
│  └─ routers/
│     ├─ __init__.py
│     └─ users.py           # /users endpoints
├─ README.md
└─ requirements.txt
```

---

## ▶️ Run Locally

1) **Create & activate venv (recommended)**
```bash
python -m venv .venv
# Windows
.venv\Scripts\activate
# macOS/Linux
source .venv/bin/activate
```

2) **Install dependencies**
```bash
pip install -r requirements.txt
```

3) **Start the server**
```bash
uvicorn app.main:app --reload
```

4) **Open interactive docs**
- Swagger UI: http://127.0.0.1:8000/docs
- ReDoc:      http://127.0.0.1:8000/redoc

A SQLite file `app.db` will be created in the project root on first run.

---

## 🛠️ API Reference

### Create User
**POST** `/users`
```json
{
  "name": "Alice",
  "email": "alice@example.com"
}
```
**201 Created →**
```json
{
  "id": 1,
  "name": "Alice",
  "email": "alice@example.com",
  "created_at": "2025-01-01T12:00:00"
}
```

### List Users
**GET** `/users?skip=0&limit=100`

### Get User by ID
**GET** `/users/1`

### Update (partial)
**PATCH** `/users/1`
```json
{
  "name": "Alice Johnson"
}
```

### Delete
**DELETE** `/users/1` → **204 No Content**

---

## ✅ Notes
- Uses **Pydantic v2** with `ConfigDict(from_attributes=True)` for ORM serialization.
- Ensures **unique emails** with clear **409 Conflict** responses.
- Limits list queries with `skip` and `limit` (validated).
- Code is organized into **models/schemas/crud/routers** for clarity and testability.

## 🔁 Switch to another DB later?
Change `DATABASE_URL` in `app/database.py`. For Postgres:
```python
DATABASE_URL = "postgresql+psycopg://user:password@localhost:5432/mydb"
```
(Install `psycopg[binary]` and update `requirements.txt`.)
