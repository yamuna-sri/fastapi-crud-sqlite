from fastapi import FastAPI
from .database import Base, engine
from .routers import users

def create_app() -> FastAPI:
    app = FastAPI(title="FastAPI CRUD with SQLite", version="1.0.0")

    # Routers
    app.include_router(users.router)

    @app.on_event("startup")
    def on_startup():
        Base.metadata.create_all(bind=engine)

    return app

app = create_app()
